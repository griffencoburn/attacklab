/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_426(unsigned x)
{
    return x + 3284633672U;
}

unsigned addval_196(unsigned x)
{
    return x + 3351742792U;
}

void setval_399(unsigned *p)
{
    *p = 342737496U;
}

unsigned addval_250(unsigned x)
{
    return x + 2421746315U;
}

void setval_325(unsigned *p)
{
    *p = 3347662944U;
}

unsigned getval_268()
{
    return 2425393752U;
}

void setval_138(unsigned *p)
{
    *p = 2425393240U;
}

unsigned addval_317(unsigned x)
{
    return x + 2428995912U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_456()
{
    return 3380136585U;
}

unsigned getval_137()
{
    return 3687107209U;
}

unsigned getval_472()
{
    return 3675838089U;
}

void setval_109(unsigned *p)
{
    *p = 3676357001U;
}

void setval_153(unsigned *p)
{
    *p = 3286288712U;
}

void setval_252(unsigned *p)
{
    *p = 3590922302U;
}

unsigned addval_180(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_293()
{
    return 3372269961U;
}

unsigned addval_319(unsigned x)
{
    return x + 3536109961U;
}

unsigned getval_495()
{
    return 3281111689U;
}

unsigned getval_487()
{
    return 3399047353U;
}

unsigned addval_362(unsigned x)
{
    return x + 3286272456U;
}

void setval_198(unsigned *p)
{
    *p = 2425411209U;
}

void setval_340(unsigned *p)
{
    *p = 3286272344U;
}

unsigned addval_369(unsigned x)
{
    return x + 3286272329U;
}

void setval_178(unsigned *p)
{
    *p = 3223374473U;
}

void setval_243(unsigned *p)
{
    *p = 3767093348U;
}

unsigned addval_482(unsigned x)
{
    return x + 2445379958U;
}

unsigned getval_157()
{
    return 3232022921U;
}

void setval_162(unsigned *p)
{
    *p = 3682910605U;
}

unsigned getval_112()
{
    return 3229931145U;
}

unsigned getval_119()
{
    return 3225995913U;
}

unsigned getval_480()
{
    return 3372794249U;
}

unsigned getval_166()
{
    return 3284846980U;
}

unsigned addval_314(unsigned x)
{
    return x + 3380926105U;
}

unsigned getval_239()
{
    return 3680556681U;
}

void setval_161(unsigned *p)
{
    *p = 2430634312U;
}

void setval_122(unsigned *p)
{
    *p = 3674784136U;
}

unsigned addval_343(unsigned x)
{
    return x + 3353381192U;
}

unsigned getval_339()
{
    return 3225998985U;
}

unsigned getval_287()
{
    return 3222853257U;
}

unsigned addval_341(unsigned x)
{
    return x + 3531917961U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
